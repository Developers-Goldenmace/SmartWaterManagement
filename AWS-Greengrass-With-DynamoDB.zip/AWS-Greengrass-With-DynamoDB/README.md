# AWS-Greengrass-With-DynamoDB
Here I have attached the Boto3 Module and GreenGrass SDK with python code to send the Data from Raspberry Pi to Store Data in AWS DynamoDB
